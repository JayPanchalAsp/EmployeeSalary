﻿using EmployeTaskDemo.entity;
using EmployeTaskDemo.Extentions;
using EmployeTaskDemo.interfaces;
using EmployeTaskDemo.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace EmployeTaskDemo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SalaryController : Controller
    {
        private readonly AppDbContext _context;

        public SalaryController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost("CalculateSalary")]
        public async Task<IActionResult> CalculateSalary([FromBody] CalculateSalary cs)
        {
            if (cs == null || cs.EmpId <= 0)
                return BadRequest("Invalid input data.");

            // Prepare parameters for stored procedure
            SqlParameter empIdParam = new SqlParameter("@EmpId", cs.EmpId);

            // Output parameter to store the calculated salary
            SqlParameter salaryAmountParam = new SqlParameter("@SalaryAmount", SqlDbType.Decimal)
            {
                Direction = ParameterDirection.Output
            };

            try
            {
                // Execute the stored procedure
                await _context.Database.ExecuteSqlRawAsync("EXEC CalculateSalary @EmpId, @SalaryAmount OUTPUT",
                    empIdParam, salaryAmountParam);

                // Check if the output parameter is DBNull before casting
                if (salaryAmountParam.Value == DBNull.Value)
                {
                    return BadRequest("Salary calculation failed. No salary amount returned.");
                }

                // Get the output salary amount after execution
                decimal calculatedSalary = (decimal)salaryAmountParam.Value;

                return Ok(new { SalaryAmount = calculatedSalary });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
