﻿using Microsoft.AspNetCore.Mvc;
using EmployeTaskDemo.entity;
using EmployeTaskDemo.interfaces;
using EmployeTaskDemo.Model;
using Microsoft.EntityFrameworkCore;
using EmployeTaskDemo.Extentions;
using EmployeTaskDemo.Dtos;
using System.Reflection;

namespace EmployeTaskDemo.Controllers
{
    [ApiController]  
    [Route("api/[controller]")]
    public class EmployeesController : ControllerBase
    {
        private readonly IRepository<Employee> _employeeRepository;
        private readonly IRepository<Salary> _salaryRepository;
        private readonly AppDbContext _context;

        public EmployeesController(IRepository<Employee> employeeRepository, IRepository<Salary> salaryRepository,AppDbContext context)
        {
            _employeeRepository = employeeRepository;
            _salaryRepository = salaryRepository;
            _context = context;
        }

        [HttpGet("GetEmployees")]
        public async Task<IActionResult> GetEmployees()
        {
            try
            {
                var employees = await _context.Employees
                    .Include(e => e.Salaries)
                    .Select(e => new EmployeeDto
                    {
                        Id = e.Id,
                        FullName = e.FullName,
                        Mobile = e.Mobile,
                        Address = e.Address,
                        PayScale = e.PayScale,
                        Salaries = e.Salaries.Select(s => new SalaryDto
                        {
                            Id = s.Id,
                            Month = s.Month,
                            Year = s.Year,
                            SalaryAmount = s.SalaryAmount
                        }).ToList()
                    })
                    .ToListAsync();

                return Ok(employees);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("AddEmployee")]
        public async Task<IActionResult> AddEmployee([FromBody] EmployeeSalary employeeDetails)
        {
            if (employeeDetails == null || string.IsNullOrEmpty(employeeDetails.FullName))
                return BadRequest("Invalid employee data.");

            if (employeeDetails.AbsentDays < 0 || employeeDetails.AbsentDays > employeeDetails.MonthDays)
                return BadRequest("Invalid absent days.");
            
            if (employeeDetails.PresentDays < 0 || employeeDetails.PresentDays > employeeDetails.MonthDays)
                return BadRequest("Invalid Present days.");

            if (employeeDetails.PresentDays + employeeDetails.AbsentDays != employeeDetails.MonthDays)
                return BadRequest("Invalid Present days and Absent days total");

            var employee = new Employee
            {
                FullName = employeeDetails.FullName,
                Mobile = employeeDetails.Mobile,
                Address = employeeDetails.Address,
                PayScale = employeeDetails.PayScale,
                IsActive = employeeDetails.IsActive
            };
            await _employeeRepository.AddAsync(employee);

            var salary = new Salary
            {
                EmpId = employee,
                Month = DateTime.Now.Month,
                Year = DateTime.Now.Year,
                MonthDays = employeeDetails.MonthDays,  
                PresentDays = employeeDetails.PresentDays,
                AbsentDays = employeeDetails.AbsentDays,
                SalaryAmount = employeeDetails.SalaryAmount,  
                CreatedDate = DateTime.Now,
                CreatedBy = "Admin"  
            };

            await _salaryRepository.AddAsync(salary);

            return Ok("Employee Data Saved Successfully");
        }
    }
}
