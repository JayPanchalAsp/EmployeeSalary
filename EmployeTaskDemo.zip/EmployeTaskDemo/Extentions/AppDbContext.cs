﻿using EmployeTaskDemo.entity;
using Microsoft.EntityFrameworkCore;

namespace EmployeTaskDemo.Extentions
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Salary> Salaries { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>()
                .HasMany(e => e.Salaries)  // Employee can have many Salaries
                .WithOne(s => s.EmpId);  // Each Salary references a single Employee
        }
    }
}
