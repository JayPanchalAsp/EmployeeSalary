﻿namespace EmployeTaskDemo.Extentions
{
    public class ApplicationServiceExtentions
    {
    }
}
