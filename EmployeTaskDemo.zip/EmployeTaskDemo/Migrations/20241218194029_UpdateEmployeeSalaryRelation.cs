﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EmployeTaskDemo.Migrations
{
    public partial class UpdateEmployeeSalaryRelation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
