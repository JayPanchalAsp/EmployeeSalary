﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EmployeTaskDemo.Migrations
{
    public partial class FixEmployeeSalaryRelationship : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Salaries_Employees_EmployeeId",
                table: "Salaries");

            migrationBuilder.DropIndex(
                name: "IX_Salaries_EmployeeId",
                table: "Salaries");

            migrationBuilder.DropColumn(
                name: "EmployeeId",
                table: "Salaries");

            migrationBuilder.RenameColumn(
                name: "EmpId",
                table: "Salaries",
                newName: "EmpIdId");

            migrationBuilder.CreateIndex(
                name: "IX_Salaries_EmpIdId",
                table: "Salaries",
                column: "EmpIdId");

            migrationBuilder.AddForeignKey(
                name: "FK_Salaries_Employees_EmpIdId",
                table: "Salaries",
                column: "EmpIdId",
                principalTable: "Employees",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Salaries_Employees_EmpIdId",
                table: "Salaries");

            migrationBuilder.DropIndex(
                name: "IX_Salaries_EmpIdId",
                table: "Salaries");

            migrationBuilder.RenameColumn(
                name: "EmpIdId",
                table: "Salaries",
                newName: "EmpId");

            migrationBuilder.AddColumn<int>(
                name: "EmployeeId",
                table: "Salaries",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Salaries_EmployeeId",
                table: "Salaries",
                column: "EmployeeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Salaries_Employees_EmployeeId",
                table: "Salaries",
                column: "EmployeeId",
                principalTable: "Employees",
                principalColumn: "Id");
        }
    }
}
