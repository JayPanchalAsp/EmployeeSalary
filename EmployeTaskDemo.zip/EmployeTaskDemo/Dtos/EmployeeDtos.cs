﻿namespace EmployeTaskDemo.Dtos
{
    public class EmployeeDto
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string Mobile { get; set; }
        public string Address { get; set; }
        public decimal PayScale { get; set; }
        public bool IsActive { get; set; }
        public List<SalaryDto> Salaries { get; set; }
    }

    public class SalaryDto
    {
        public int Id { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public decimal SalaryAmount { get; set; }
    }
}
