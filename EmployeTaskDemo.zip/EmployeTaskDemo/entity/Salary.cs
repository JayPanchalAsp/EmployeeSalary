﻿namespace EmployeTaskDemo.entity
{
    public class Salary
    {
        public int Id { get; set; }              
        public Employee EmpId { get; set; }           
        public int Month { get; set; }           
        public int Year { get; set; }            
        public int MonthDays { get; set; } = 26;
        public int PresentDays { get; set; }     
        public int AbsentDays { get; set; }      
        public decimal SalaryAmount { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
}
