﻿namespace EmployeTaskDemo.entity
{
    public class Employee
    {
        public int Id { get; set; }               
        public string FullName { get; set; }    
        public string Mobile { get; set; }       
        public string Address { get; set; }      
        public decimal PayScale { get; set; }  
        public bool IsActive { get; set; }

        public ICollection<Salary> Salaries { get; set; }

    }


}
 