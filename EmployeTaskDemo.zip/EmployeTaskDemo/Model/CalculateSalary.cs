﻿namespace EmployeTaskDemo.Model
{
    public class CalculateSalary
    {
        public int EmpId { get; set; }
    }
}
