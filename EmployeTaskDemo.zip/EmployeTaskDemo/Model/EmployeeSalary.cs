﻿namespace EmployeTaskDemo.Model
{
    public class EmployeeSalary
    {
            public string FullName { get; set; }
            public string Mobile { get; set; }
            public string Address { get; set; }
            public decimal PayScale { get; set; }
            public bool IsActive { get; set; }

            public int MonthDays { get; set; }   // Number of working days in the month
            public int PresentDays { get; set; }  // Number of present days in the month
            public int AbsentDays { get; set; }   // Number of absent days in the month
            public decimal SalaryAmount { get; set; }  // The salary amount
    }
}
